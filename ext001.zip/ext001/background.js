let color = '#aabbcc'; // background color

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ color });
});